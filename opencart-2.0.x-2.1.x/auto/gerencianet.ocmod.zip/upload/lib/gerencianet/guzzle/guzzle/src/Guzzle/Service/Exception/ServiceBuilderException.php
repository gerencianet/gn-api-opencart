<?php

namespace Guzzle\Service\Exception;

use Guzzle\Common\Exception\RuntimeException;

class ServiceBuilderException extends RuntimeException {}
